import { useState, useRef } from "react";
import Card from "../wrappers/Card";


function DataForm({datas}){
    
    const temakorRef = useRef();
    const feladasNapRef = useRef();
    const hataridoRef = useRef();
    const leirasRef = useRef();
    const [tipus, setTipus] = useState("");
    const [tantargy, setTantargy] = useState("");

    const dataHandler = () => {

        datas({
            temakor: temakorRef.current.value,
            feladva: feladasNapRef.current.value,
            hatarido: hataridoRef.current.value,
            leiras: leirasRef.current.value,
            tipus: tipus,
            tantargy: tantargy
        })
    }

    return (
        <Card>
            <form onSubmit={(e) => e.preventDefault()} id="form">
                <h3>Tantárgy neve:</h3>
                <br />
                <select onChange={(e) => setTantargy(e.currentTarget.value)}>
                    <option value="">-- Válasszon --</option>
                    <option value="Angol">Angol</option>
                    <option value="Történelem">Történelem</option>
                    <option value="Backend">Backend</option>
                    <option value="Pénzügyi ismeretek">Pénzügyi ismeretek</option>
                    <option value="Linux ismeretek">Linux ismeretek</option>
                    <option value="Webprogramozás">Webprogramozás</option>
                    <option value="Frontend">Frontend</option>
                    <option value="Asztali alkalmazások">Asztali alkalmazások</option>
                    <option value="Irodalom">Irodalom</option>
                    <option value="Nyelvtan">Nyelvtan</option>
                </select>
                <br /><br />
                <h3>Témakör:</h3>
                <br />
                <input type="text" ref={temakorRef}/>
                <br /><br />
                <h3>Feladás napja:</h3>
                <br />
                <input type="date" ref={feladasNapRef}/>
                <br /><br />
                <h3>Határidő:</h3>
                <br />
                <input type="date" ref={hataridoRef}/>
                <br /><br />
                <h3>Feladat bővebb leírása:</h3>
                <br />
                <textarea ref={leirasRef}/>
                <br /><br />
                <h4>Szóbeli</h4>
                <input type="radio" name="radio" value="Szóbeli" onChange={(e) => setTipus(e.currentTarget.value)}/>
                <br />
                <h4>Írásbeli</h4>
                <input type="radio" name="radio" value="Írásbeli" onChange={(e) => setTipus(e.currentTarget.value)}/>
                <br /><br />
                <button type="submit" onClick={dataHandler}>Küldés</button>
            </form>    
        </Card>
    )
}
export default DataForm;