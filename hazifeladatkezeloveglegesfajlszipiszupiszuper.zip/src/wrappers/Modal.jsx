import moment from "moment";
import styles from "./modal.module.css";
import { IoIosWarning } from "react-icons/io";


function Modal({ item, onClose }) {

    const today = moment().startOf("day");
    const deadline = moment(item.hatarido, "YYYY-MM-DD").startOf("day");
    const difference = deadline.diff(today, "days");
    let expired = false;

    if (difference < 0){
        expired = true;
    }

    return (
        <div className={styles.modal}>

            <h2>{item.temakor}</h2>
            <p>Tantárgy: {item.tantargy}</p>
            <p>Határidő: {item.hatarido}</p>
            <p>{item.leiras}</p>

            {expired &&
                <h3>A határidő lejárt! <IoIosWarning /></h3>
            }

            <button onClick={onClose}>Bezárás</button>
        </div>
    )
}

export default Modal;