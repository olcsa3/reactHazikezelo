import classes from '../wrappers/Title.module.css';

function Title(){
    return(
        <>
            <div className={classes.title}>Házi feladat kezelő</div>
        </>
    )
}
export default Title;