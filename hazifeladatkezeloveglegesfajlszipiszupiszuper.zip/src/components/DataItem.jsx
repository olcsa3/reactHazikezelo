import moment from "moment";
import Card from "../wrappers/Card";
import styles from "../wrappers/card.module.css";
import { IoIosWarning } from "react-icons/io";
import { IoIosInformationCircle } from "react-icons/io";
import { MdNotificationImportant } from "react-icons/md";

function DataItem ({ 
    index,
    temakor, 
    feladva, 
    hatarido, 
    leiras, 
    tipus, 
    tantargy,
    completed,
    onDelete,
    onToggle
}) {

    const today = moment().startOf("day");
    const deadline = moment(hatarido, "YYYY-MM-DD").startOf("day");

    const daysLeft = deadline.diff(today, "days");
    const isExpired = daysLeft < 0;
    const nearDeadline = daysLeft <= 2 && daysLeft > 0;
    const currentDay = daysLeft == 0;

    return (
        <Card>

            <ul className={completed ? styles.completed : ""}>
                <li><span>Tantárgy:</span> {tantargy}</li>
                <li><span>Témakör:</span> {temakor}</li>
                <li><span>Feladva:</span> {feladva}</li>
                <li><span>Határidő:</span> {hatarido}</li>
                <li><span>Típus:</span> {tipus}</li>
                <li><span>Leírás:</span> {leiras}</li>
            </ul>

            {!completed && isExpired && 
                <p className={styles.expired}><IoIosWarning /> Lejárt!</p>
            }

            {!completed && nearDeadline &&
                <p className={styles.warning}><IoIosInformationCircle /> Közel a határidő!</p>
            }

            {!completed && currentDay &&
                <p className={styles.deadline}><MdNotificationImportant /> A határidő ma van!</p>
            }
            <div className={styles.btn}>
                <button className={styles.greenbtn} onClick={() => onToggle(index)}>
                    {completed ? "Visszaállítás" : "Kész"}
                </button>

                <button onClick={() => onDelete(index)}>
                    Törlés
                </button>
            </div>

        </Card>
    )
}

export default DataItem;