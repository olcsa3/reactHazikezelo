import DataItem from "./DataItem";

function DataList ({values, onDelete, onToggle, onOpenModal}){
    return (
        <>
            {values.map((value, index) => 
            <DataItem 
            key={index} 
            index={index}
            {...value}
            onDelete={onDelete}
            onToggle={onToggle}
            onOpenModal={onOpenModal}
            />)}
        </>
    )
}
export default DataList;