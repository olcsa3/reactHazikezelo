import { useState } from 'react'
import './App.css'
import DataForm from './components/DataForm'
import DataList from './components/DataList'
import Modal from './wrappers/Modal'
import Backdrop from './wrappers/Backdrop'
import moment from 'moment'
import Title from './components/Title'

function App() {

  const [items, setItems] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);

  const addItem = (data) => {
  const newItem = { ...data, completed: false };
  setItems(prev => [...prev, newItem]);

  const today = moment().startOf("day");
  const deadline = moment(data.hatarido).startOf("day");

  if (today.isAfter(deadline)) {
    setSelectedItem(newItem);
    }
  }

  const toggleComplete = (index) => {
  setItems(prev =>
    prev.map((item, i) =>
      i === index ? { ...item, completed: !item.completed } : item
      )
    );
  }

  const deleteItem = (index) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  }

  const openModal = () => {
    setSelectedItem(item)
  }

  const closeModal = () => {
    setSelectedItem(null);
  }

  return (
    <>
      <Title/>

      <DataForm datas={addItem}/>

      <DataList 
        values={items}
        onDelete={deleteItem}
        onToggle={toggleComplete}
        openModal={openModal}
      />

      {selectedItem && (
        <>
          <Backdrop onClick={closeModal}/>
          <Modal item={selectedItem} onClose={closeModal}/>
        </>
      )}
    </>
  )
}

export default App;