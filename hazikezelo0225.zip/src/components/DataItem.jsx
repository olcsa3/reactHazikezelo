import moment from "moment";
import Card from "../wrappers/Card";
import styles from "../wrappers/card.module.css";

function DataItem ({ 
    index,
    temakor, 
    feladva, 
    hatarido, 
    leiras, 
    tipus, 
    tantargy,
    completed,
    onDelete,
    onToggle
}) {

    const today = moment().startOf("day");
    const deadline = moment(hatarido, "YYYY-MM-DD").startOf("day");

    const daysLeft = deadline.diff(today, "days");
    const isExpired = daysLeft < 0;
    const nearDeadline = daysLeft <= 2 && daysLeft >= 0;

    return (
        <Card>

            <ul className={completed ? styles.completed : ""}>
                <li>Tantárgy: {tantargy}</li>
                <li>Témakör: {temakor}</li>
                <li>Feladva: {feladva}</li>
                <li>Határidő: {hatarido}</li>
                <li>Típus: {tipus}</li>
                <li>Leírás: {leiras}</li>
            </ul>

            {!completed && isExpired && 
                <p className={styles.expired}>⛔ Lejárt</p>
            }

            {!completed && nearDeadline &&
                <p className={styles.warning}>⚠️ Közel a határidő</p>
            }

            <button onClick={() => onToggle(index)}>
                {completed ? "Visszaállítás" : "Kész"}
            </button>

            <button onClick={() => onDelete(index)}>
                Törlés
            </button>

        </Card>
    )
}

export default DataItem;