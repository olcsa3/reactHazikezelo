import moment from "moment";
import styles from "./modal.module.css";

function Modal({ item, onClose }) {

    const today = moment().startOf("day");
    const deadline = moment(item.hatarido, "YYYY-MM-DD").startOf("day");
    const isExpired = today.isAfter(deadline);

    return (
        <div className={styles.modal}>

            <h2>{item.temakor}</h2>
            <p>Tantárgy: {item.tantargy}</p>
            <p>Határidő: {item.hatarido}</p>
            <p>{item.leiras}</p>

            {isExpired && (
                <h3 style={{color:"red"}}>
                    ⛔ EZ A FELADAT LEJÁRT
                </h3>
            )}

            <button onClick={onClose}>Bezárás</button>
        </div>
    )
}

export default Modal;